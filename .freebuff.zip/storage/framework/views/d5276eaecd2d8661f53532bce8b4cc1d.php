<?php $__env->startSection('title', 'Pesan Masuk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h3 class="fw-bold mb-1">Pesan Masuk</h3>
        <p class="text-secondary mb-0">Pesan yang dikirim pengunjung melalui halaman Kontak Kami.</p>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width:40px">#</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Subjek</th>
                        <th>Pesan</th>
                        <th style="width:120px">Waktu</th>
                        <th style="width:140px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($item->is_dibaca ? '' : 'table-primary'); ?>">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="fw-semibold">
                                <?php if (! ($item->is_dibaca)): ?>
                                    <span class="badge text-bg-primary rounded-pill me-1">Baru</span>
                                <?php endif; ?>
                                <?php echo e($item->nama); ?>

                            </td>
                            <td class="small"><?php echo e($item->email); ?></td>
                            <td class="small"><?php echo e($item->subjek ?: '—'); ?></td>
                            <td class="small text-secondary"><?php echo e(\Illuminate\Support\Str::limit($item->pesan, 60)); ?></td>
                            <td class="small"><?php echo e($item->created_at->diffForHumans()); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.pesan.show', $item)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-envelope-open me-1"></i>Baca
                                </a>
                                <form action="<?php echo e(route('admin.pesan.destroy', $item)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Yakin hapus pesan dari <?php echo e($item->nama); ?>?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-secondary py-4">Belum ada pesan masuk.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($pesan->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/admin/pesan/index.blade.php ENDPATH**/ ?>