<?php $__env->startSection('title', 'Galeri Kegiatan'); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-primary text-white py-5">
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page">Galeri Kegiatan</li>
                </ol>
            </nav>
            <h1 class="fw-bold mb-0">Galeri Kegiatan</h1>
            <p class="mb-0 opacity-75">Dokumentasi aktivitas perusahaan bersama klien dan mitra.</p>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            
            <div class="d-flex flex-wrap gap-2 mb-4">
                <a href="<?php echo e(route('galeri.index')); ?>"
                   class="btn btn-sm rounded-pill <?php echo e($kategoriDipilih ? 'btn-outline-primary' : 'btn-primary'); ?>">Semua</a>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('galeri.index', ['kategori' => $kat])); ?>"
                       class="btn btn-sm rounded-pill <?php echo e($kategoriDipilih === $kat ? 'btn-primary' : 'btn-outline-primary'); ?>"><?php echo e($kat); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row g-3">
                <?php $__empty_1 = true; $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="galeri-item shadow-sm">
                            <img src="<?php echo e(asset($foto->gambar ?: 'images/placeholder-galeri.svg')); ?>" alt="<?php echo e($foto->judul); ?>">
                            <div class="overlay">
                                <div>
                                    <div class="fw-bold small"><?php echo e($foto->judul); ?></div>
                                    <div class="small opacity-75">
                                        <?php echo e($foto->kategori ?: 'Kegiatan'); ?> &middot; <?php echo e(optional($foto->tanggal_kegiatan)->translatedFormat('d M Y')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-1"></i>Belum ada foto galeri tersedia.
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="mt-4 d-flex justify-content-center">
                <?php echo e($galeri->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/galeri/index.blade.php ENDPATH**/ ?>