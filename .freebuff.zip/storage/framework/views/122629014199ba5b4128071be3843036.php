<?php $__env->startSection('title', 'Detail Pesan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h3 class="fw-bold mb-1">Detail Pesan</h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb small mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.pesan.index')); ?>">Pesan Masuk</a></li>
                <li class="breadcrumb-item active" aria-current="page">Detail</li>
            </ol>
        </nav>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between flex-wrap gap-2 mb-4">
                <div>
                    <h4 class="fw-bold mb-1"><?php echo e($pesan->nama); ?></h4>
                    <div class="text-secondary small">
                        <i class="bi bi-envelope me-1"></i><?php echo e($pesan->email); ?>

                        <?php if($pesan->telepon): ?>
                            &middot; <i class="bi bi-telephone me-1"></i><?php echo e($pesan->telepon); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-end">
                    <?php if($pesan->subjek): ?>
                        <div class="fw-semibold"><?php echo e($pesan->subjek); ?></div>
                    <?php endif; ?>
                    <div class="small text-secondary"><?php echo e($pesan->created_at->translatedFormat('d F Y, H:i')); ?></div>
                </div>
            </div>

            <hr>

            <div class="text-secondary" style="white-space: pre-line"><?php echo e($pesan->pesan); ?></div>

            <hr>
            <div class="d-flex gap-2">
                <a href="mailto:<?php echo e($pesan->email); ?>?subject=Balasan%20untuk%20pesan%20Anda" class="btn btn-primary">
                    <i class="bi bi-reply me-1"></i>Balas via Email
                </a>
                <form action="<?php echo e(route('admin.pesan.destroy', $pesan)); ?>" method="POST"
                      onsubmit="return confirm('Yakin hapus pesan ini?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-outline-danger">
                        <i class="bi bi-trash me-1"></i>Hapus
                    </button>
                </form>
                <a href="<?php echo e(route('admin.pesan.index')); ?>" class="btn btn-outline-secondary">Kembali</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/admin/pesan/show.blade.php ENDPATH**/ ?>