<?php $__env->startSection('title', 'Kelola Galeri Kegiatan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h3 class="fw-bold mb-1">Galeri Kegiatan</h3>
            <p class="text-secondary mb-0">Kelola foto kegiatan perusahaan yang tampil di website.</p>
        </div>
        <a href="<?php echo e(route('admin.galeri.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Tambah Foto
        </a>
    </div>

    <div class="row g-3">
        <?php $__empty_1 = true; $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-6 col-md-4 col-xl-3">
                <div class="card border-0 shadow-sm rounded-4 h-100 overflow-hidden">
                    <img src="<?php echo e(asset($foto->gambar)); ?>" alt="<?php echo e($foto->judul); ?>" class="card-img-top" style="height: 160px; object-fit: cover;">
                    <div class="card-body p-3">
                        <div class="fw-semibold small"><?php echo e(\Illuminate\Support\Str::limit($foto->judul, 40)); ?></div>
                        <div class="small text-secondary">
                            <?php echo e($foto->kategori ?: 'Kegiatan'); ?> &middot; <?php echo e($foto->tanggal_kegiatan?->format('d/m/Y') ?? '—'); ?>

                        </div>
                        <div class="d-flex gap-1 mt-2">
                            <a href="<?php echo e(route('admin.galeri.edit', $foto)); ?>" class="btn btn-sm btn-outline-primary flex-grow-1">
                                <i class="bi bi-pencil me-1"></i>Edit
                            </a>
                            <form action="<?php echo e(route('admin.galeri.destroy', $foto)); ?>" method="POST"
                                  onsubmit="return confirm('Yakin hapus foto \"<?php echo e($foto->judul); ?>\"?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-1"></i>Belum ada foto galeri. Klik "Tambah Foto" untuk menambahkan.
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-3">
        <?php echo e($galeri->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/admin/galeri/index.blade.php ENDPATH**/ ?>