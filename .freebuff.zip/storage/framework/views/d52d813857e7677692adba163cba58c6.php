<?php $__env->startSection('title', $artikel->judul); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-primary text-white py-5">
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('artikel.index')); ?>" class="text-white-50 text-decoration-none">Artikel</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page"><?php echo e(\Illuminate\Support\Str::limit($artikel->judul, 40)); ?></li>
                </ol>
            </nav>
            <h1 class="fw-bold mb-0" style="font-size: clamp(1.5rem, 3vw, 2.25rem)"><?php echo e($artikel->judul); ?></h1>
            <div class="d-flex flex-wrap align-items-center gap-3 mt-2 small opacity-75">
                <span><i class="bi bi-person-circle me-1"></i><?php echo e($artikel->penulis ?? 'Redaksi'); ?></span>
                <span><i class="bi bi-calendar3 me-1"></i><?php echo e(optional($artikel->published_at)->translatedFormat('d F Y')); ?></span>
                <span><i class="bi bi-eye me-1"></i><?php echo e($artikel->views); ?> x dibaca</span>
                <?php if($artikel->kategori): ?> <span class="badge text-bg-light text-primary"><?php echo e($artikel->kategori); ?></span> <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-8">
                    <img src="<?php echo e(asset($artikel->gambar ?: 'images/placeholder-artikel.svg')); ?>" class="rounded-4 w-100 shadow-sm mb-4" alt="<?php echo e($artikel->judul); ?>" style="max-height: 420px; object-fit: cover;">
                    <div class="artikel-isi fs-6 text-secondary" style="white-space: pre-line"><?php echo e($artikel->isi); ?></div>

                    <hr class="my-5">
                    <a href="<?php echo e(route('artikel.index')); ?>" class="btn btn-outline-primary">
                        <i class="bi bi-arrow-left me-1"></i>Kembali ke Daftar Artikel
                    </a>
                </div>

                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h5 class="fw-bold mb-3">Artikel Lainnya</h5>
                            <div class="d-grid gap-3">
                                <?php $__empty_1 = true; $__currentLoopData = $artikelLain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a href="<?php echo e(route('artikel.show', $lain->slug)); ?>" class="d-flex gap-3 text-decoration-none text-dark">
                                        <img src="<?php echo e(asset($lain->gambar ?: 'images/placeholder-artikel.svg')); ?>" alt="<?php echo e($lain->judul); ?>" class="rounded-3" style="width: 72px; height: 56px; object-fit: cover;">
                                        <div>
                                            <div class="small fw-semibold"><?php echo e(\Illuminate\Support\Str::limit($lain->judul, 55)); ?></div>
                                            <div class="small text-secondary"><?php echo e(optional($lain->published_at)->translatedFormat('d M Y')); ?></div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <span class="text-secondary small">Belum ada artikel lain.</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/artikel/show.blade.php ENDPATH**/ ?>