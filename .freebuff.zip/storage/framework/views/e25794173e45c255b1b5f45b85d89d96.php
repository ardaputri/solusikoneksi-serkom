<?php $__env->startSection('title', 'Kontak Kami'); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-primary text-white py-5">
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page">Kontak Kami</li>
                </ol>
            </nav>
            <h1 class="fw-bold mb-0">Kontak Kami</h1>
            <p class="mb-0 opacity-75">Kirim pertanyaan atau permintaan kerja sama, tim kami akan segera merespons.</p>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                
                <div class="col-lg-5">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <h4 class="fw-bold mb-3">Informasi Kontak</h4>
                            <ul class="list-unstyled d-grid gap-3">
                                <li class="d-flex gap-3">
                                    <span class="icon-besar rounded-4 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center flex-shrink-0">
                                        <i class="bi bi-geo-alt"></i>
                                    </span>
                                    <div>
                                        <div class="fw-semibold">Alamat</div>
                                        <div class="text-secondary small"><?php echo e($profil->alamat ?? '—'); ?></div>
                                    </div>
                                </li>
                                <li class="d-flex gap-3">
                                    <span class="icon-besar rounded-4 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center flex-shrink-0">
                                        <i class="bi bi-telephone"></i>
                                    </span>
                                    <div>
                                        <div class="fw-semibold">Telepon</div>
                                        <div class="text-secondary small"><?php echo e($profil->telepon ?? '—'); ?></div>
                                    </div>
                                </li>
                                <li class="d-flex gap-3">
                                    <span class="icon-besar rounded-4 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center flex-shrink-0">
                                        <i class="bi bi-envelope"></i>
                                    </span>
                                    <div>
                                        <div class="fw-semibold">Email</div>
                                        <div class="text-secondary small"><?php echo e($profil->email ?? '—'); ?></div>
                                    </div>
                                </li>
                                <li class="d-flex gap-3">
                                    <span class="icon-besar rounded-4 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center flex-shrink-0">
                                        <i class="bi bi-clock"></i>
                                    </span>
                                    <div>
                                        <div class="fw-semibold">Jam Operasional</div>
                                        <div class="text-secondary small"><?php echo e($profil->jam_operasional ?? '—'); ?></div>
                                    </div>
                                </li>
                            </ul>

                            <div class="d-flex gap-2 mt-4">
                                <?php if($profil?->facebook): ?> <a href="<?php echo e($profil->facebook); ?>" class="btn btn-outline-primary btn-sm rounded-pill" target="_blank" rel="noopener"><i class="bi bi-facebook me-1"></i>Facebook</a> <?php endif; ?>
                                <?php if($profil?->instagram): ?> <a href="<?php echo e($profil->instagram); ?>" class="btn btn-outline-primary btn-sm rounded-pill" target="_blank" rel="noopener"><i class="bi bi-instagram me-1"></i>Instagram</a> <?php endif; ?>
                                <?php if($profil?->youtube): ?> <a href="<?php echo e($profil->youtube); ?>" class="btn btn-outline-primary btn-sm rounded-pill" target="_blank" rel="noopener"><i class="bi bi-youtube me-1"></i>YouTube</a> <?php endif; ?>
                                <?php if($profil?->linkedin): ?> <a href="<?php echo e($profil->linkedin); ?>" class="btn btn-outline-primary btn-sm rounded-pill" target="_blank" rel="noopener"><i class="bi bi-linkedin me-1"></i>LinkedIn</a> <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-lg-7">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <h4 class="fw-bold mb-1">Kirim Pesan</h4>
                            <p class="text-secondary small mb-4">Isi formulir berikut dan kami akan menghubungi Anda kembali.</p>

                            <form action="<?php echo e(route('kontak.store')); ?>" method="POST" novalidate>
                                <?php echo csrf_field(); ?>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="nama" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input type="text" name="nama" id="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               value="<?php echo e(old('nama')); ?>" placeholder="Masukkan nama Anda" required>
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                        <input type="email" name="email" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               value="<?php echo e(old('email')); ?>" placeholder="nama@email.com" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="telepon" class="form-label">No. Telepon</label>
                                        <input type="text" name="telepon" id="telepon" class="form-control <?php $__errorArgs = ['telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               value="<?php echo e(old('telepon')); ?>" placeholder="08xxxxxxxxxx">
                                        <?php $__errorArgs = ['telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="subjek" class="form-label">Subjek</label>
                                        <input type="text" name="subjek" id="subjek" class="form-control <?php $__errorArgs = ['subjek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               value="<?php echo e(old('subjek')); ?>" placeholder="Subjek pesan">
                                        <?php $__errorArgs = ['subjek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <label for="pesan" class="form-label">Pesan <span class="text-danger">*</span></label>
                                        <textarea name="pesan" id="pesan" rows="5" class="form-control <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                  placeholder="Tuliskan pesan Anda..." required><?php echo e(old('pesan')); ?></textarea>
                                        <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary px-4">
                                            <i class="bi bi-send me-1"></i>Kirim Pesan
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            
            <?php if($profil?->maps_embed_url): ?>
                <div class="mt-4">
                    <h4 class="fw-bold mb-3">Lokasi Kami</h4>
                    <div class="ratio ratio-21x9 rounded-4 overflow-hidden shadow">
                        <iframe src="<?php echo e($profil->maps_embed_url); ?>" style="border:0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Lokasi kantor"></iframe>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/kontak.blade.php ENDPATH**/ ?>