<!DOCTYPE html>
<html lang="id">
<?php ($profil = $profil ?? \App\Models\ProfilPerusahaan::first()); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo e(($profil->tagline ?? null) ?: 'Company Profile PT Solusi Koneksi Anda'); ?>">
    <title><?php echo $__env->yieldContent('title', 'Beranda'); ?> — <?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/logo.svg')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="d-flex flex-column min-vh-100">

    
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top shadow">
        <div class="container">
            <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/logo-putih.svg')); ?>" alt="Logo <?php echo e(config('app.name')); ?>">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
                    aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('profil.*') ? 'active' : ''); ?>" href="<?php echo e(route('profil.show')); ?>">Profil Perusahaan</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('produk.*') ? 'active' : ''); ?>" href="<?php echo e(route('produk.index')); ?>">Produk / Layanan</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('artikel.*') ? 'active' : ''); ?>" href="<?php echo e(route('artikel.index')); ?>">Artikel</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('galeri.*') ? 'active' : ''); ?>" href="<?php echo e(route('galeri.index')); ?>">Galeri Kegiatan</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('kontak.*') ? 'active' : ''); ?>" href="<?php echo e(route('kontak.show')); ?>">Kontak Kami</a></li>
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>"><i class="bi bi-speedometer2 me-1"></i>Admin</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    
    <?php if(session('success')): ?>
        <div class="container mt-3">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
            </div>
        </div>
    <?php endif; ?>

    
    <main class="flex-grow-1">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer class="bg-dark text-white pt-5 pb-3 mt-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5 class="fw-bold mb-3"><?php echo e($profil->nama_perusahaan ?? config('app.name')); ?></h5>
                    <p class="text-white-50"><?php echo e(\Illuminate\Support\Str::limit($profil->deskripsi ?? 'Menghubungkan solusi digital untuk bisnis Anda.', 140)); ?></p>
                    <div class="d-flex gap-3 fs-5">
                        <?php if($profil?->facebook): ?> <a href="<?php echo e($profil->facebook); ?>" class="footer-link" target="_blank" rel="noopener"><i class="bi bi-facebook"></i></a> <?php endif; ?>
                        <?php if($profil?->instagram): ?> <a href="<?php echo e($profil->instagram); ?>" class="footer-link" target="_blank" rel="noopener"><i class="bi bi-instagram"></i></a> <?php endif; ?>
                        <?php if($profil?->youtube): ?> <a href="<?php echo e($profil->youtube); ?>" class="footer-link" target="_blank" rel="noopener"><i class="bi bi-youtube"></i></a> <?php endif; ?>
                        <?php if($profil?->linkedin): ?> <a href="<?php echo e($profil->linkedin); ?>" class="footer-link" target="_blank" rel="noopener"><i class="bi bi-linkedin"></i></a> <?php endif; ?>
                    </div>
                </div>
                <div class="col-6 col-lg-2">
                    <h6 class="fw-bold mb-3">Navigasi</h6>
                    <ul class="list-unstyled d-grid gap-2">
                        <li><a href="<?php echo e(route('home')); ?>" class="footer-link">Beranda</a></li>
                        <li><a href="<?php echo e(route('profil.show')); ?>" class="footer-link">Profil Perusahaan</a></li>
                        <li><a href="<?php echo e(route('produk.index')); ?>" class="footer-link">Produk / Layanan</a></li>
                        <li><a href="<?php echo e(route('artikel.index')); ?>" class="footer-link">Artikel</a></li>
                    </ul>
                </div>
                <div class="col-6 col-lg-2">
                    <h6 class="fw-bold mb-3">Lainnya</h6>
                    <ul class="list-unstyled d-grid gap-2">
                        <li><a href="<?php echo e(route('galeri.index')); ?>" class="footer-link">Galeri Kegiatan</a></li>
                        <li><a href="<?php echo e(route('kontak.show')); ?>" class="footer-link">Kontak Kami</a></li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <h6 class="fw-bold mb-3"><i class="bi bi-geo-alt me-1"></i>Hubungi Kami</h6>
                    <ul class="list-unstyled text-white-50 d-grid gap-2">
                        <li><i class="bi bi-geo-alt-fill me-2"></i><?php echo e($profil->alamat ?? '—'); ?></li>
                        <li><i class="bi bi-telephone-fill me-2"></i><?php echo e($profil->telepon ?? '—'); ?></li>
                        <li><i class="bi bi-envelope-fill me-2"></i><?php echo e($profil->email ?? '—'); ?></li>
                        <li><i class="bi bi-clock me-2"></i><?php echo e($profil->jam_operasional ?? '—'); ?></li>
                    </ul>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start text-white-50">
                    &copy; <?php echo e(date('Y')); ?> <?php echo e($profil->nama_perusahaan ?? config('app.name')); ?>. Hak cipta dilindungi.
                </div>
                <div class="col-md-6 text-center text-md-end text-white-50">
                    Dibuat dengan Laravel &amp; Bootstrap
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/layouts/app.blade.php ENDPATH**/ ?>