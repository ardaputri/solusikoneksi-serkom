<?php $__env->startSection('title', 'Kelola Produk / Layanan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h3 class="fw-bold mb-1">Produk / Layanan</h3>
            <p class="text-secondary mb-0">Kelola daftar produk dan layanan yang tampil di website.</p>
        </div>
        <a href="<?php echo e(route('admin.produk.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Tambah Produk
        </a>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width:70px">Gambar</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th style="width:90px">Urutan</th>
                        <th style="width:100px">Status</th>
                        <th style="width:160px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <img src="<?php echo e(asset($item->gambar ?: 'images/placeholder-produk.svg')); ?>" alt="<?php echo e($item->nama); ?>"
                                     class="rounded" style="width:56px;height:40px;object-fit:cover;">
                            </td>
                            <td class="fw-semibold"><?php echo e($item->nama); ?></td>
                            <td><span class="badge text-bg-light border"><?php echo e($item->kategori ?: '—'); ?></span></td>
                            <td class="small"><?php echo e($item->harga ?: '—'); ?></td>
                            <td><?php echo e($item->urutan); ?></td>
                            <td>
                                <?php if($item->is_aktif): ?>
                                    <span class="badge text-bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge text-bg-secondary">Nonaktif</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('produk.show', $item->slug)); ?>" class="btn btn-sm btn-outline-secondary" target="_blank" title="Lihat">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.produk.edit', $item)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('admin.produk.destroy', $item)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Yakin hapus produk \"<?php echo e($item->nama); ?>\"?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-secondary py-4">Belum ada produk/layanan. Klik "Tambah Produk" untuk menambahkan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($produk->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/admin/produk/index.blade.php ENDPATH**/ ?>