<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="hero py-5">
        <div class="container py-5">
            <div class="row align-items-center g-5">
                <div class="col-lg-7">
                    <div class="hero-brand">PT Solusi Koneksi Anda</div>
                    <span class="badge text-bg-light mb-3 px-3 py-2">
                        <i class="bi bi-stars me-1"></i>Solusi Teknologi Informasi Terpercaya
                    </span>
                    <h1 class="display-5 mb-3"><?php echo e($profil->tagline ?? 'Menghubungkan Solusi Digital untuk Bisnis Anda'); ?></h1>
                    <p class="lead mb-4"><?php echo e(\Illuminate\Support\Str::limit($profil->deskripsi ?? '', 220)); ?></p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-light btn-lg px-4 fw-semibold">
                            <i class="bi bi-grid me-2"></i>Lihat Layanan Kami
                        </a>
                        <a href="<?php echo e(route('kontak.show')); ?>" class="btn btn-outline-light btn-lg px-4">
                            <i class="bi bi-envelope me-2"></i>Hubungi Kami
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 d-none d-lg-block text-center">
                    <div class="bg-white rounded-4 shadow p-4">
                        <div class="row text-primary">
                            <div class="col-4"><i class="bi bi-globe2 fs-1"></i><div class="small text-dark mt-1">Konektivitas</div></div>
                            <div class="col-4"><i class="bi bi-shield-lock fs-1"></i><div class="small text-dark mt-1">Keamanan</div></div>
                            <div class="col-4"><i class="bi bi-cloud-arrow-up fs-1"></i><div class="small text-dark mt-1">Cloud</div></div>
                        </div>
                        <hr>
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="display-6 fw-bold text-primary"><?php echo e(\App\Models\ProdukLayanan::aktif()->count()); ?>+</div>
                                <div class="small text-secondary">Layanan</div>
                            </div>
                            <div class="col-6">
                                <div class="display-6 fw-bold text-primary"><?php echo e($profil->berdiri_sejak ?? '2015'); ?></div>
                                <div class="small text-secondary">Berdidir sejak</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-5">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-6">
                    <h2 class="section-title fw-bold">Tentang <?php echo e($profil->nama_perusahaan ?? config('app.name')); ?></h2>
                    <p class="text-secondary mt-3"><?php echo e($profil->deskripsi ?? 'Profil perusahaan belum tersedia.'); ?></p>
                    <a href="<?php echo e(route('profil.show')); ?>" class="btn btn-outline-primary mt-2">
                        Selengkapnya <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                </div>
                <div class="col-lg-6">
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body">
                                    <i class="bi bi-eye text-primary fs-2"></i>
                                    <h6 class="fw-bold mt-2">Visi</h6>
                                    <p class="small text-secondary mb-0"><?php echo e(\Illuminate\Support\Str::limit($profil->visi ?? '—', 100)); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body">
                                    <i class="bi bi-bullseye text-primary fs-2"></i>
                                    <h6 class="fw-bold mt-2">Misi</h6>
                                    <p class="small text-secondary mb-0"><?php echo e(\Illuminate\Support\Str::limit($profil->misi ?? '—', 100)); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="card border-0 shadow-sm bg-primary text-white">
                                <div class="card-body d-flex align-items-center gap-3">
                                    <i class="bi bi-headset fs-1"></i>
                                    <div>
                                        <div class="fw-bold">Butuh konsultasi?</div>
                                        <div class="small opacity-75">Tim kami siap membantu kebutuhan teknologi informasi bisnis Anda.</div>
                                    </div>
                                    <a href="<?php echo e(route('kontak.show')); ?>" class="btn btn-light ms-auto d-none d-md-block">Kontak</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-5 bg-light">
        <div class="container">
            <div class="d-flex justify-content-between align-items-end flex-wrap gap-2 mb-4">
                <div>
                    <h2 class="section-title fw-bold mb-1">Produk &amp; Layanan</h2>
                    <p class="text-secondary mb-0">Solusi lengkap untuk mendukung operasional bisnis Anda.</p>
                </div>
                <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-primary">Lihat Semua <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card card-produk h-100 shadow-sm rounded-4">
                            <div class="card-body p-4">
                                <div class="icon-besar rounded-4 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center mb-3">
                                    <i class="<?php echo e($item->ikon ?: 'bi bi-box-seam'); ?>"></i>
                                </div>
                                <h5 class="fw-bold"><?php echo e($item->nama); ?></h5>
                                <p class="text-secondary small mb-2"><?php echo e(\Illuminate\Support\Str::limit($item->deskripsi, 110)); ?></p>
                                <?php if($item->harga): ?>
                                    <span class="badge text-bg-light border"><?php echo e($item->harga); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-white border-0 px-4 pb-4">
                                <a href="<?php echo e(route('produk.show', $item->slug)); ?>" class="btn btn-sm btn-outline-primary rounded-pill">
                                    Detail <i class="bi bi-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-secondary">Belum ada produk/layanan tersedia.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    
    <section class="py-5">
        <div class="container">
            <div class="d-flex justify-content-between align-items-end flex-wrap gap-2 mb-4">
                <div>
                    <h2 class="section-title fw-bold mb-1">Artikel &amp; Informasi Terkini</h2>
                    <p class="text-secondary mb-0">Berita, tips, dan informasi terbaru dari kami.</p>
                </div>
                <a href="<?php echo e(route('artikel.index')); ?>" class="btn btn-primary">Semua Artikel <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card card-artikel h-100 shadow-sm rounded-4 overflow-hidden">
                            <div class="overflow-hidden">
                                <img src="<?php echo e(asset($item->gambar ?: 'images/placeholder-artikel.svg')); ?>" class="card-img-top" alt="<?php echo e($item->judul); ?>" style="height: 190px; object-fit: cover;">
                            </div>
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center gap-2 small text-secondary mb-2">
                                    <span class="badge text-bg-primary"><?php echo e($item->kategori ?: 'Informasi'); ?></span>
                                    <span><i class="bi bi-calendar3 me-1"></i><?php echo e(optional($item->published_at)->translatedFormat('d M Y')); ?></span>
                                </div>
                                <h6 class="fw-bold"><?php echo e($item->judul); ?></h6>
                                <p class="text-secondary small mb-2"><?php echo e(\Illuminate\Support\Str::limit($item->ringkasan, 100)); ?></p>
                                <a href="<?php echo e(route('artikel.show', $item->slug)); ?>" class="small fw-semibold text-decoration-none">
                                    Baca selengkapnya <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-secondary">Belum ada artikel diterbitkan.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    
    <section class="py-5 bg-light">
        <div class="container">
            <div class="d-flex justify-content-between align-items-end flex-wrap gap-2 mb-4">
                <div>
                    <h2 class="section-title fw-bold mb-1">Galeri Kegiatan</h2>
                    <p class="text-secondary mb-0">Dokumentasi aktivitas perusahaan bersama klien dan mitra.</p>
                </div>
                <a href="<?php echo e(route('galeri.index')); ?>" class="btn btn-primary">Buka Galeri <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
            <div class="row g-3">
                <?php $__empty_1 = true; $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-6 col-md-4">
                        <div class="galeri-item shadow-sm">
                            <img src="<?php echo e(asset($foto->gambar ?: 'images/placeholder-galeri.svg')); ?>" alt="<?php echo e($foto->judul); ?>">
                            <div class="overlay">
                                <div>
                                    <div class="fw-bold small"><?php echo e($foto->judul); ?></div>
                                    <div class="small opacity-75"><?php echo e(optional($foto->tanggal_kegiatan)->translatedFormat('d M Y')); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-secondary">Belum ada foto galeri.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/home.blade.php ENDPATH**/ ?>