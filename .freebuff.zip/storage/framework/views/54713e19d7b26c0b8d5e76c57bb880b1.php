<?php $__env->startSection('title', $produk->nama); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-primary text-white py-5">
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('produk.index')); ?>" class="text-white-50 text-decoration-none">Produk / Layanan</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page"><?php echo e($produk->nama); ?></li>
                </ol>
            </nav>
            <h1 class="fw-bold mb-0"><?php echo e($produk->nama); ?></h1>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-8">
                    <img src="<?php echo e(asset($produk->gambar ?: 'images/placeholder-produk.svg')); ?>" class="rounded-4 w-100 shadow-sm" alt="<?php echo e($produk->nama); ?>" style="max-height: 420px; object-fit: cover;">
                    <h3 class="fw-bold mt-4"><?php echo e($produk->nama); ?></h3>
                    <div class="mb-3 d-flex flex-wrap gap-2">
                        <?php if($produk->kategori): ?> <span class="badge text-bg-primary"><?php echo e($produk->kategori); ?></span> <?php endif; ?>
                        <?php if($produk->harga): ?> <span class="badge text-bg-light border"><i class="bi bi-tag me-1"></i><?php echo e($produk->harga); ?></span> <?php endif; ?>
                    </div>
                    <p class="text-secondary" style="white-space: pre-line"><?php echo e($produk->deskripsi ?? 'Deskripsi belum tersedia.'); ?></p>
                    <a href="<?php echo e(route('kontak.show')); ?>" class="btn btn-primary mt-2">
                        <i class="bi bi-chat-dots me-1"></i>Tanya Layanan Ini
                    </a>
                </div>

                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h5 class="fw-bold mb-3">Layanan Lainnya</h5>
                            <div class="d-grid gap-3">
                                <?php $__empty_1 = true; $__currentLoopData = $produkLain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a href="<?php echo e(route('produk.show', $lain->slug)); ?>" class="d-flex align-items-center gap-3 text-decoration-none text-dark">
                                        <span class="rounded-3 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                            <i class="<?php echo e($lain->ikon ?: 'bi bi-box-seam'); ?> fs-5"></i>
                                        </span>
                                        <span class="fw-semibold small"><?php echo e($lain->nama); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <span class="text-secondary small">Tidak ada layanan lain.</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/produk/show.blade.php ENDPATH**/ ?>