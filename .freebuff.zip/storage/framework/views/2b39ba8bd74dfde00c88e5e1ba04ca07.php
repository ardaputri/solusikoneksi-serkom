<?php $__env->startSection('title', 'Produk / Layanan'); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-primary text-white py-5">
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page">Produk / Layanan</li>
                </ol>
            </nav>
            <h1 class="fw-bold mb-0">Produk &amp; Layanan</h1>
            <p class="mb-0 opacity-75">Solusi teknologi informasi untuk segala skala bisnis.</p>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            
            <div class="d-flex flex-wrap gap-2 mb-4">
                <a href="<?php echo e(route('produk.index')); ?>"
                   class="btn btn-sm rounded-pill <?php echo e($kategoriDipilih ? 'btn-outline-primary' : 'btn-primary'); ?>">Semua</a>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('produk.index', ['kategori' => $kat])); ?>"
                       class="btn btn-sm rounded-pill <?php echo e($kategoriDipilih === $kat ? 'btn-primary' : 'btn-outline-primary'); ?>"><?php echo e($kat); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card card-produk h-100 shadow-sm rounded-4">
                            <img src="<?php echo e(asset($item->gambar ?: 'images/placeholder-produk.svg')); ?>" class="card-img-top" alt="<?php echo e($item->nama); ?>" style="height: 180px; object-fit: cover;">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    <span class="icon-besar rounded-4 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center">
                                        <i class="<?php echo e($item->ikon ?: 'bi bi-box-seam'); ?>"></i>
                                    </span>
                                    <?php if($item->kategori): ?>
                                        <span class="badge text-bg-light border"><?php echo e($item->kategori); ?></span>
                                    <?php endif; ?>
                                </div>
                                <h5 class="fw-bold"><?php echo e($item->nama); ?></h5>
                                <p class="text-secondary small"><?php echo e(\Illuminate\Support\Str::limit($item->deskripsi, 120)); ?></p>
                                <?php if($item->harga): ?>
                                    <div class="fw-semibold text-primary small"><i class="bi bi-tag me-1"></i><?php echo e($item->harga); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-white border-0 px-4 pb-4">
                                <a href="<?php echo e(route('produk.show', $item->slug)); ?>" class="btn btn-sm btn-outline-primary rounded-pill">
                                    Selengkapnya <i class="bi bi-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-1"></i>Belum ada produk/layanan yang tersedia.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/produk/index.blade.php ENDPATH**/ ?>