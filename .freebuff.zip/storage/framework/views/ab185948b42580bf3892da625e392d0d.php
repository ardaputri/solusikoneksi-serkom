<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> — <?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/logo.svg')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
</head>
<body>
<div class="d-flex flex-column flex-lg-row">
    
    <aside class="sidebar p-3 flex-shrink-0">
        <a href="<?php echo e(route('home')); ?>" class="d-flex align-items-center gap-2 text-white fw-bold fs-5 mb-3 px-2 py-2 text-decoration-none">
            <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo" style="filter: brightness(0) invert(1); height: 32px;">
        </a>
        <hr class="border-secondary">
        <nav class="d-grid gap-1">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <div class="text-uppercase small text-white-50 px-3 mt-3 mb-1">Konten Dinamis</div>
            <a href="<?php echo e(route('admin.produk.index')); ?>" class="<?php echo e(request()->routeIs('admin.produk.*') ? 'active' : ''); ?>">
                <i class="bi bi-box-seam"></i> Produk / Layanan
            </a>
            <a href="<?php echo e(route('admin.artikel.index')); ?>" class="<?php echo e(request()->routeIs('admin.artikel.*') ? 'active' : ''); ?>">
                <i class="bi bi-newspaper"></i> Artikel
            </a>
            <a href="<?php echo e(route('admin.galeri.index')); ?>" class="<?php echo e(request()->routeIs('admin.galeri.*') ? 'active' : ''); ?>">
                <i class="bi bi-images"></i> Galeri Kegiatan
            </a>
            <div class="text-uppercase small text-white-50 px-3 mt-3 mb-1">Lainnya</div>
            <a href="<?php echo e(route('admin.profil.edit')); ?>" class="<?php echo e(request()->routeIs('admin.profil.*') ? 'active' : ''); ?>">
                <i class="bi bi-building"></i> Profil Perusahaan
            </a>
            <a href="<?php echo e(route('admin.pesan.index')); ?>" class="<?php echo e(request()->routeIs('admin.pesan.*') ? 'active' : ''); ?>">
                <i class="bi bi-envelope-paper"></i> Pesan Masuk
                <?php if(\App\Models\PesanKontak::where('is_dibaca', false)->count() > 0): ?>
                    <span class="badge text-bg-danger ms-auto"><?php echo e(\App\Models\PesanKontak::where('is_dibaca', false)->count()); ?></span>
                <?php endif; ?>
            </a>
        </nav>
        <hr class="border-secondary">
        <a href="<?php echo e(route('home')); ?>" class="d-block small text-white-50 px-3 mb-2 text-decoration-none">
            <i class="bi bi-globe me-1"></i>Lihat Website
        </a>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-light btn-sm w-100">
                <i class="bi bi-box-arrow-right me-1"></i>Keluar (<?php echo e(auth()->user()->name); ?>)
            </button>
        </form>
    </aside>

    
    <main class="flex-grow-1 p-3 p-md-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <div class="fw-semibold mb-1"><i class="bi bi-exclamation-triangle me-1"></i>Terjadi kesalahan:</div>
                <ul class="mb-0 small">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/layouts/admin.blade.php ENDPATH**/ ?>