<?php $__env->startSection('title', 'Artikel & Informasi Terkini'); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-primary text-white py-5">
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page">Artikel</li>
                </ol>
            </nav>
            <h1 class="fw-bold mb-0">Artikel &amp; Informasi Terkini</h1>
            <p class="mb-0 opacity-75">Berita, tips, dan informasi terbaru seputar teknologi informasi.</p>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            
            <div class="d-flex flex-wrap gap-2 mb-4">
                <a href="<?php echo e(route('artikel.index')); ?>"
                   class="btn btn-sm rounded-pill <?php echo e($kategoriDipilih ? 'btn-outline-primary' : 'btn-primary'); ?>">Semua</a>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('artikel.index', ['kategori' => $kat])); ?>"
                       class="btn btn-sm rounded-pill <?php echo e($kategoriDipilih === $kat ? 'btn-primary' : 'btn-outline-primary'); ?>"><?php echo e($kat); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card card-artikel h-100 shadow-sm rounded-4 overflow-hidden">
                            <div class="overflow-hidden">
                                <img src="<?php echo e(asset($item->gambar ?: 'images/placeholder-artikel.svg')); ?>" class="card-img-top" alt="<?php echo e($item->judul); ?>" style="height: 190px; object-fit: cover;">
                            </div>
                            <div class="card-body p-4 d-flex flex-column">
                                <div class="d-flex align-items-center gap-2 small text-secondary mb-2 flex-wrap">
                                    <span class="badge text-bg-primary"><?php echo e($item->kategori ?: 'Informasi'); ?></span>
                                    <span><i class="bi bi-calendar3 me-1"></i><?php echo e(optional($item->published_at)->translatedFormat('d M Y')); ?></span>
                                    <span><i class="bi bi-eye me-1"></i><?php echo e($item->views); ?></span>
                                </div>
                                <h6 class="fw-bold"><?php echo e($item->judul); ?></h6>
                                <p class="text-secondary small flex-grow-1"><?php echo e(\Illuminate\Support\Str::limit($item->ringkasan, 110)); ?></p>
                                <a href="<?php echo e(route('artikel.show', $item->slug)); ?>" class="small fw-semibold text-decoration-none mt-auto">
                                    Baca selengkapnya <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-1"></i>Belum ada artikel yang diterbitkan.
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="mt-4 d-flex justify-content-center">
                <?php echo e($artikel->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/artikel/index.blade.php ENDPATH**/ ?>