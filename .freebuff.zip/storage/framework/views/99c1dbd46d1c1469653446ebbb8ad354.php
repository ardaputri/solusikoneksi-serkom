<?php $__env->startSection('title', 'Kelola Artikel'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h3 class="fw-bold mb-1">Artikel</h3>
            <p class="text-secondary mb-0">Kelola artikel dan informasi terkini yang tampil di website.</p>
        </div>
        <a href="<?php echo e(route('admin.artikel.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Tambah Artikel
        </a>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width:70px">Gambar</th>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Penulis</th>
                        <th style="width:130px">Terbit</th>
                        <th style="width:90px">Dibaca</th>
                        <th style="width:100px">Status</th>
                        <th style="width:160px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <img src="<?php echo e(asset($item->gambar ?: 'images/placeholder-artikel.svg')); ?>" alt="<?php echo e($item->judul); ?>"
                                     class="rounded" style="width:56px;height:40px;object-fit:cover;">
                            </td>
                            <td class="fw-semibold"><?php echo e(\Illuminate\Support\Str::limit($item->judul, 60)); ?></td>
                            <td><span class="badge text-bg-light border"><?php echo e($item->kategori ?: '—'); ?></span></td>
                            <td class="small"><?php echo e($item->penulis ?: '—'); ?></td>
                            <td class="small"><?php echo e($item->published_at?->format('d/m/Y') ?? '—'); ?></td>
                            <td class="small"><?php echo e($item->views); ?></td>
                            <td>
                                <?php if($item->is_published): ?>
                                    <span class="badge text-bg-success">Terbit</span>
                                <?php else: ?>
                                    <span class="badge text-bg-secondary">Draft</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if($item->is_published): ?>
                                    <a href="<?php echo e(route('artikel.show', $item->slug)); ?>" class="btn btn-sm btn-outline-secondary" target="_blank" title="Lihat">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.artikel.edit', $item)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('admin.artikel.destroy', $item)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Yakin hapus artikel \"<?php echo e($item->judul); ?>\"?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-secondary py-4">Belum ada artikel. Klik "Tambah Artikel" untuk menambahkan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($artikel->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/admin/artikel/index.blade.php ENDPATH**/ ?>