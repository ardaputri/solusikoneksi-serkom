<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h3 class="fw-bold mb-1">Dashboard</h3>
            <p class="text-secondary mb-0">Selamat datang, <?php echo e(auth()->user()->name); ?>. Kelola konten website Anda di sini.</p>
        </div>
        <span class="text-secondary small"><i class="bi bi-calendar3 me-1"></i><?php echo e(now()->translatedFormat('d F Y')); ?></span>
    </div>

    
    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <span class="rounded-4 bg-primary bg-opacity-10 text-primary d-inline-flex align-items-center justify-content-center" style="width:52px;height:52px;">
                        <i class="bi bi-box-seam fs-4"></i>
                    </span>
                    <div>
                        <div class="fs-4 fw-bold"><?php echo e($statistik['produk']); ?></div>
                        <div class="small text-secondary">Produk / Layanan</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <span class="rounded-4 bg-success bg-opacity-10 text-success d-inline-flex align-items-center justify-content-center" style="width:52px;height:52px;">
                        <i class="bi bi-newspaper fs-4"></i>
                    </span>
                    <div>
                        <div class="fs-4 fw-bold"><?php echo e($statistik['artikel']); ?></div>
                        <div class="small text-secondary">Artikel</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <span class="rounded-4 bg-warning bg-opacity-10 text-warning d-inline-flex align-items-center justify-content-center" style="width:52px;height:52px;">
                        <i class="bi bi-images fs-4"></i>
                    </span>
                    <div>
                        <div class="fs-4 fw-bold"><?php echo e($statistik['galeri']); ?></div>
                        <div class="small text-secondary">Foto Galeri</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <span class="rounded-4 bg-danger bg-opacity-10 text-danger d-inline-flex align-items-center justify-content-center" style="width:52px;height:52px;">
                        <i class="bi bi-envelope-paper fs-4"></i>
                    </span>
                    <div>
                        <div class="fs-4 fw-bold"><?php echo e($statistik['pesan_baru']); ?></div>
                        <div class="small text-secondary">Pesan Belum Dibaca</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3">
        
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center py-3 border-0">
                    <h6 class="fw-bold mb-0"><i class="bi bi-envelope-paper me-1"></i>Pesan Terbaru</h6>
                    <a href="<?php echo e(route('admin.pesan.index')); ?>" class="btn btn-sm btn-outline-primary">Lihat semua</a>
                </div>
                <div class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $pesanTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('admin.pesan.show', $pesan)); ?>" class="list-group-item list-group-item-action py-3">
                            <div class="d-flex justify-content-between">
                                <span class="fw-semibold <?php echo e($pesan->is_dibaca ? '' : 'text-primary'); ?>"><?php echo e($pesan->nama); ?></span>
                                <small class="text-secondary"><?php echo e($pesan->created_at->diffForHumans()); ?></small>
                            </div>
                            <div class="small text-secondary"><?php echo e(\Illuminate\Support\Str::limit($pesan->pesan, 90)); ?></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="list-group-item py-4 text-center text-secondary">Belum ada pesan masuk.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center py-3 border-0">
                    <h6 class="fw-bold mb-0"><i class="bi bi-newspaper me-1"></i>Artikel Terbaru</h6>
                    <a href="<?php echo e(route('admin.artikel.index')); ?>" class="btn btn-sm btn-outline-primary">Kelola</a>
                </div>
                <div class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $artikelTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('admin.artikel.edit', $item)); ?>" class="list-group-item list-group-item-action py-3">
                            <div class="fw-semibold small"><?php echo e(\Illuminate\Support\Str::limit($item->judul, 60)); ?></div>
                            <div class="small text-secondary">
                                <?php echo e($item->published_at?->format('d/m/Y') ?? 'Draft'); ?>

                                &middot; <?php echo e($item->views); ?> x dibaca
                                <?php if(! $item->is_published): ?> <span class="badge text-bg-secondary">Draft</span> <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="list-group-item py-4 text-center text-secondary">Belum ada artikel.</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mt-3 bg-primary text-white">
                <div class="card-body">
                    <h6 class="fw-bold"><i class="bi bi-lightbulb me-1"></i>Tips</h6>
                    <p class="small mb-2 opacity-75">Profil perusahaan bersifat statis — tidak bisa ditambah, namun dapat diperbaharui melalui menu <strong>Profil Perusahaan</strong>.</p>
                    <a href="<?php echo e(route('admin.profil.edit')); ?>" class="btn btn-light btn-sm">Perbarui Profil</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\company-profile-pt-ska\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>